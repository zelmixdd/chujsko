<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="menu.css">
    <title>Wungabunga Italiano - Menu</title>
</head>
<body>
    <header>
        <div class="h-img">
            <a href="../index.html">
                <img src="../img/Logo.jpg" alt="Logo">
            </a>
        </div>
        <div class="navbar">
            <ul>
                <li><a href="../index.html">Strona Główna</a></li>
                <li><a href="menu.html">Menu</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="kontakt.html">Kontakt</a></li>
                <li><a href="koszyk.php">Koszyk</a></li>
            </ul>
        </div>
    </header>
    <main>
        <div class="menu">
        <?php

        $db = new mysqli('localhost', 'root', '', 'zyd_z_mydla');
        $q = "SELECT * FROM menu";
        $result = $db->query($q);
        $names = array();
        $prices = array();
        while($row = $result->fetch_assoc()) {
            $id_f = $row['id_f'];
            $Nazwa = $row['Nazwa'];
            $cena = $row['Cena'];
            $Nazwy[$id_f] = $Nazwa;
            $Ceny[$id_f] = $Cena;

        }
            ?>

        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </main>
    <footer>
        <hr>
        <br>
        <h3>Newsletter:</h3>
        <div class="newsletter">
            <form action="/url" method="GET" class="input">
                <input type="text" placeholder="Imię" required>
                <input type="text" placeholder="E-Mail" required>
                <button type="submit">Dołącz</button>
            </form>
        </div>
        <br>
        <p class="footertext">
         Designed by: Krystian Zelmański, Jakub Kopeć
        </p>
        <br>
    </footer>
</body>
</html>