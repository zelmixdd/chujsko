<?php 
session_start();
?>


<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="koszyk.css">
    <title>Wungabunga Italiano - Koszyk</title>
</head>

<body>
    <header>
        <div class="h-img">
            <a href="../index.html">
                <img src="../img/Logo.jpg" alt="Logo">
            </a>
        </div>
        <div class="navbar">
            <ul>
            <li><a href="../index.html">Strona Główna</a></li>
                <li><a href="menu.html">Menu</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="kontakt.html">Kontakt</a></li>
                <li><a href="koszyk.php">Koszyk</a></li>
            </ul>
        </div>
    </header>
    <?php
    if(isset($_REQUEST['id']))
    {
        if(isset($_SESSION['cart'])) 
        {
            array_push($_SESSION['cart'], $_REQUEST['id']);
        
        }
        else {
            $_SESSION['cart'] = array();
            array_push($_SESSION['cart'], $_REQUEST['id']);
        }
    }
    if (isset($_SESSION['cart'])) {
        $db = new mysqli('localhost', 'root', '', 'zyd_z_mydla');
        $q = "SELECT * FROM menu";
        $result = $db->query($q);
        $names = array();
        $prices = array();
        while($row = $result->fetch_assoc()) {
            $id_f = $row['id_f'];
            $Nazwa = $row['Nazwa'];
            $cena = $row['Cena'];
            $Nazwy[$id_f] = $Nazwa;
            $Ceny[$id_f] = $Cana;
        }
        echo '<table>';
        $sum = 0;
        foreach ($_SESSION['cart'] as $cartItem) {
            echo '<tr>';
            echo '<td>' . $Nazwy[$cartItem] . '</td>';
            echo '<td>' . $Ceny[$cartItem] .'zł', '</td>';
            echo '</tr>';
            $sum += $Ceny[$cartItem];
        }
        echo '</table>';

        echo 'Suma zamówienia: ' . $sum . ' zł';
    } else {
        echo 'Koszyk jest pusty';
    }
    ?>
    <main>
        <div class="top">
            <h2>Twoje Informacje do zamówienia:</h2>
            <div class="order">
                <form action="order.php" method="POST">
                    <input type="text" name="firstName">
                    <input type="text" name="lastName">
                    <input type="text" name="address">
                    <input type="text" name="phone">
                    <input type="submit" value="Zamów">

                </form>
            </div>
            <div class="summary">
                <h3>Do zapłaty: </h3>
                <button>Zamawiam</button>
            </div>
        </div>
        <div class="right">
            <img src="../img/pizza-hawajska.jpeg" alt="">
        </div>
    </main>
    <footer>
        <br>
        <hr>
        <br>
        <h3>Nestletter:</h3>
        <div class="newsletter">
            <form action="/url" method="GET" class="input">
                <input type="text" placeholder="Imię" required>
                <input type="text" placeholder="E-Mail" required>
                <button type="submit">Dołącz</button>
            </form>
        </div>
        <br>
        <p class="footertext">
            © Designed by: Krystian Zelmański, Jakub Kopeć
        </p>
        <br>
    </footer>
</body>

</html>