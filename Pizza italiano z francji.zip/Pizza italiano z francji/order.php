<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
$cart = $_SESSION['cart'];
$firstName = $_REQUEST['firstName'];
$lastName = $_REQUEST['lastName'];
$address = $_REQUEST['address'];
$phone = $_REQUEST['phone']; 

$db = new mysqli('localhost', 'root', '', 'zyd_z_mydla');
$q = $db->prepare("INSERT INTO zamowienie VALUES (NULL,?,?,?,?)");
$q->bind_param('ssss', $firstName, $lastName, $addressName, $phone);
$orderID = $db->insert_id;

$q = $db->prepare("INSERT INTO orderedfood VALUES (NULL,?,?)");

foreach ($cart as $id_f) {
    $q->bind_param('ii', $orderID, $id_f);
    $q->execute();
}
?>
</body>
</html>